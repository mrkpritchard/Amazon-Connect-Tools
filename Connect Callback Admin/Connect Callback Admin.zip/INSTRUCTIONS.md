# Installation & Setup - Connect Callback Admin

> **Disclaimer:** This tool was extracted from a customized internal deployment
> and stripped of all corporate/account-specific data. Every organization value
> has been replaced with a named placeholder. A fresh setup will likely need some
> adjustments for your own AWS account, Amazon Connect instance, and naming. Treat
> this as a working reference, not a turnkey drop-in.

## Prerequisites
- An AWS account with permission to deploy Lambda, API Gateway, S3, and IAM
- AWS CLI and AWS SAM CLI installed and configured (`aws configure`)
- An Amazon Connect instance (instance ID required for most tools)
- Node.js or Python installed, depending on the tool's runtime

## Install
1. Replace every placeholder listed below with your own values.
2. Backend: `sam build` then `sam deploy --guided` (prompts for `template.yaml` params).
3. Copy the API URL from the SAM output into the config block near the top of `index.html`.
4. Host the frontend: upload `index.html` and assets to S3 (or any static host).
5. Open the page and verify it connects to your backend.

## Be aware
- Authentication was removed for standalone use - add your own access control before exposing publicly.
- Region, Connect instance IDs, and resource names must match your environment.
- Review IAM policy JSON files and scope them to least privilege.

## Placeholders to replace

## `YOUR_COGNITO_USER_POOL_ID`

Cognito user pool ID (e.g. us-east-1_XXXXXXXXX). Cognito -> User pools -> your pool. Set in the SAM template parameter and/or the frontend config block.

Appears in:
- index.html (line 532)
- index.html (line 544)
- Additional Files\cognito-policy.json (line 11)

## `YOUR_COGNITO_APP_CLIENT_ID`

Cognito app client ID. Cognito -> your pool -> App integration -> App clients. Set in the frontend config block.

Appears in:
- index.html (line 533)
- index.html (line 545)

## `YOUR_API_ID`

API Gateway ID from your SAM deploy output (the 10-char subdomain in ...execute-api... URLs). Paste into the frontend config after deploying the backend.

Appears in:
- index.html (line 534)
- index.html (line 546)

## `@example.com`

Your email domain (used in any example/admin email addresses).

Appears in:
- index.html (line 455)

## `YOUR_CONNECT_INSTANCE_ID`

Your Amazon Connect instance ID. Connect console -> your instance; the ARN ends in instance/<this-id>. Tools ship configured for a single instance - if a region->instance map appears in the code, fill in your one instance (or remove the regions you do not use).

Appears in:
- index.js (line 53)
- template-eu.yaml (line 8)
- template-us.yaml (line 8)
- template-us.yaml (line 12)
- Additional Files\eventbridge-pattern-eu.json (line 6)
- Additional Files\eventbridge-pattern-us.json (line 6)
- Additional Files\Lambda\Main admin portal API lambda\index.js (line 53)
- Additional Files\lambda-package\index.js (line 53)

## `YOUR_CLOUDFRONT_DOMAIN`

Your CloudFront domain, e.g. dxxxxxxxx.cloudfront.net.

Appears in:
- index.js (line 116)
- template-us.yaml (line 20)

## `your-portal-domain.example.com`

Your custom portal domain, if you use one.

Appears in:
- index.js (line 115)
- index.js (line 117)
- Additional Files\DOCUMENTATION.html (line 516)
- Additional Files\Lambda\Main admin portal API lambda\index.js (line 115)
- Additional Files\lambda-package\index.js (line 115)

## `YOUR_AWS_ACCOUNT_ID`

Your 12-digit AWS account ID. AWS Console -> top-right account menu. Usually passed automatically via ${AWS::AccountId} in the SAM template.

Appears in:
- Additional Files\cognito-policy.json (line 11)
- Additional Files\eventbridge-pattern-eu.json (line 6)
- Additional Files\eventbridge-pattern-us.json (line 6)
- Additional Files\invoke-policy-eu.json (line 7)
- Additional Files\invoke-policy-us.json (line 7)
- Additional Files\kinesis-policy.json (line 14)

## `your-org`

Your organization short name/alias (used in resource names).

Appears in:
- Additional Files\kinesis-policy.json (line 14)

---
Frontend values live in the config block near the top of `index.html`; backend
values are `template.yaml` parameters that `sam deploy --guided` will prompt for.

